</div>
    <footer class="bg-gray-800 text-white p-4 text-center">
        <p>&copy; 2025 Library Movie System</p>
    </footer>
</body>
</html>